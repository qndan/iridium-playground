# Building

To build the bindings, navigate into the package: `cd packages/iridium-simulator`.

You will need CMake and Emscripten. You also need a TypeScript less than version 6 on your PATH.

Run these commands:

- `emcmake cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug`
- `cmake --build build`

This will build the bindings into `./build`. After this, you just need to run `cmake --build build` to rebuild.

If you are building for release, change the last flag in the `emcmake` command to `-DCMAKE_BUILD_TYPE=Release`.

## IDE Support

If your IDE is flagging errors, you might also also have to add this flag to the `emcmake` command: `-DCMAKE_EXPORT_COMPILE_COMMANDS=on`.
This adds `compile_commands.json` to the build directory. It will help your IDE identify that you are using Emscripten plus some other stuff.
You will probably get some errors in your IDE still, but you can just ignore them, as long as everything still compiles.

# Testing

Use `npm run test-ant`, `npm run sbmltestsuite`, and `npm run biomodels -- simulate`.

# Antimony

## Generating Grammar

Use `npm run --workspace iridium-simulator antlr4ts`.

ANTLR will generate TypeScript that does not match our TypeScript config. To fix this, just
add `// @ts-nocheck` to the top of every generated file in `packages/antimony-language/src/generated/`.

Here is a command that will do that: `sed -i '' '1s;^;// @ts-nocheck\n;' packages/iridium-simulator/src/antimony/generated/*.ts`
